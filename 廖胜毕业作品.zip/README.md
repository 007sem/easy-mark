# Easy Mark

轻量级在线编辑 markdown

`vue3` + `less` + `vite`

使用 `markdown-it` + `heighlight.js` 渲染

联系作者 `廖胜` 380204098@qq.com
学号: `190210123` 


运行指令

```
npm install && npm run dev
```
